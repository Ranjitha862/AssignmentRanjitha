//
//  PhotoViewController.swift
//  LoginextAssignment
//
//  Created by Ranjitha S on 26/04/21.
//  Copyright © 2021 Ranjitha S. All rights reserved.
//

import UIKit
import BSImagePicker
import Photos

class PhotoViewController: UIViewController, UINavigationControllerDelegate {

    @IBOutlet weak var btnPhoto: UIButton?
    @IBOutlet weak var image: UIImageView?
    
   fileprivate var imagePicker = UIImagePickerController()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

       
    }
    
    @IBAction func btnPhotoTapped(_ sender: UIButton) {
        
        let imagePicker = ImagePickerController()
        imagePicker.settings.selection.max = 5
        imagePicker.settings.theme.selectionStyle = .numbered
        imagePicker.settings.fetch.assets.supportedMediaTypes = [.image, .video]
        imagePicker.settings.selection.unselectOnReachingMax = true
        
        let start = Date()
        self.presentImagePicker(imagePicker, select: { (asset) in
        }, deselect: { (asset) in
        }, cancel: { (assets) in
        }, finish: { (assets) in
        }, completion: {
            let finish = Date()
            print(finish.timeIntervalSince(start))
            
        })
    }

    @IBAction func openCamera(_ sender: UIButton) {
        
        camera()
    }
}

extension PhotoViewController: UIImagePickerControllerDelegate {
    
   func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {

        
        guard let selectedImage = info[.originalImage] as? UIImage else {
            fatalError("Expected a dictionary containing an image, but was provided the following: \(info)")
        }

        // Set photoImageView to display the selected image.
        image?.image = selectedImage

        // Dismiss the picker.
        dismiss(animated: true, completion: nil)
    }

    func camera(){
        
        var actionSheetController = UIAlertController(title: nil, message: nil, preferredStyle: .actionSheet)
        
        if (UIDevice.current.userInterfaceIdiom == .pad) {
           actionSheetController = UIAlertController(title: nil, message: nil, preferredStyle: .alert)
        }
        let takePhotoActionButton = UIAlertAction(title: "Take photo", style: .default) { action -> Void in
            self.openCamera()
        }
        actionSheetController.addAction(takePhotoActionButton)
        imagePicker.delegate = self
        
        let cancelActionButton = UIAlertAction(title: "Cancel", style: .cancel) { action -> Void in
            self.dismiss(animated: true, completion: nil)
        }
        actionSheetController.addAction(cancelActionButton)
        
        
        self.present(actionSheetController, animated: true, completion: nil)
    }
    
    func openCamera(){
        
        if(UIImagePickerController .isSourceTypeAvailable(UIImagePickerController.SourceType.camera)){
            imagePicker.sourceType = UIImagePickerController.SourceType.camera
            self.present(imagePicker, animated: true, completion: nil)
        }
    }
}
