//
//  CommonMethods.swift
//  LoginextAssignment
//
//  Created by Ranjitha S on 28/04/21.
//  Copyright © 2021 Ranjitha S. All rights reserved.
//

import Foundation
import UIKit


extension UIView{
    
    public func roundCorners(_ cornerRadius: CGFloat) {
        
        self.layer.cornerRadius = cornerRadius
        self.clipsToBounds = true
        self.layer.masksToBounds = true
        
    }
}
