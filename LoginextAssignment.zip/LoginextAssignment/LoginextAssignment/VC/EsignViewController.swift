//
//  EsignViewController.swift
//  LoginextAssignment
//
//  Created by Ranjitha S on 26/04/21.
//  Copyright © 2021 Ranjitha S. All rights reserved.
//

import UIKit

class EsignViewController: UIViewController, YPSignatureDelegate {

     @IBOutlet weak var btnClear: UIButton?
    @IBOutlet weak var signatureView: YPDrawSignatureView!
    @IBOutlet weak var btnSave: UIButton?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        signatureView.delegate = self
        btnClear?.roundCorners(10.0)
        btnSave?.roundCorners(5.0)
    }
 
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    @IBAction func clearSignature(_ sender: UIButton) {
        self.signatureView.clear()
    }
    
    // Function for saving signature
    @IBAction func saveSignature(_ sender: UIButton) {
      
        if let signatureImage = self.signatureView.getSignature(scale: 10) {
            
            UIImageWriteToSavedPhotosAlbum(signatureImage, nil, nil, nil)
            self.signatureView.clear()
        }
    }
}


extension EsignViewController{
  
    func didStart(_ view : YPDrawSignatureView) {
        print("Started Drawing")
    }
    
    func didFinish(_ view : YPDrawSignatureView) {
        print("Finished Drawing")
    }
}
